# I.A.I Studio website

One-page website for I.A.I Studio: AI videos and images for advertising.

- `index.html` is the whole site (styles, images and videos are embedded in it).
- Open it in a browser to preview.
